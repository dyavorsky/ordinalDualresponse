## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
set.seed(1)

## -----------------------------------------------------------------------------
library(ordinalDR)
beta <- c(a2 = 0.8, a3 = -0.5, b2 = 0.4, b3 = 1.0, price = -0.9)
cut <- c(-1.0, 0.2, 1.2, 2.2)
des <- dr_design(3600, J = 4, seed = 42)
dat <- dr_simulate(des, matrix(beta, 1, 5), cut, model = "B", seed = 43)
table(dat$y) / length(dat$y)
fit <- dr_mle(dat)
fit

## -----------------------------------------------------------------------------
dat_bin <- dr_dichotomize(dat, k = 4)
fit_bin <- dr_mle(dat_bin)
round(rbind(ordinal = fit$se_beta, binary_t2b = fit_bin$se_beta), 4)

## -----------------------------------------------------------------------------
mu <- log(rowSums(exp(matrix(des$X %*% beta, ncol = 4, byrow = TRUE))))
c(W5 = mean(dr_omega(mu, cut, "B")),
  top2box = mean(dr_omega(mu, cut[3], "B")),
  topbox = mean(dr_omega(mu, cut[4], "B")))

## -----------------------------------------------------------------------------
dr_spec_tests(dat, mle = fit)

## -----------------------------------------------------------------------------
dr_optimal_cuts(5, "B", m0 = 0.6, s = 0.5)
dr_equal_share_cuts(5, "B", m0 = 0.6, s = 0.5)

